import Cart from "../models/cart.js";
import Order from "../models/order.js";
import Seller from "../models/seller.js";
import CommissionPolicy from "../models/commissionPolicy.js";
import QRCode from "qrcode";
import {
  buildSellerQrPayload,
  buildSellerQrText,
  isLatestSellerQrPayload
} from "../services/sellerQrPayloadService.js";
import { findClosestBranch, getOrderDeliveryCharge } from "../services/deliveryChargeService.js";
import User from "../models/user.js";

/**
 * ======================================================
 * ORDER CONTROLLER
 * ======================================================
 * Responsibilities:
 * - Checkout (cart → orders)
 * - Split orders by seller
 * - Buyer order history
 * - Seller order view
 * - Seller proof upload + seller QR retrieval
 * ======================================================
 */

async function getSellerFromAuthUser(user) {
  if (user.role !== "seller") {
    return null;
  }

  return Seller.findOne({ userId: user.id });
}

function serializeDeliveryCenter(branch) {
  if (!branch) return null;

  return {
    branchId: branch._id?.toString() || null,
    branchCode: branch.branchCode || "",
    branchName: branch.branchName || "",
    address: branch.address || "",
    city: branch.city || "",
    district: branch.district || "",
    province: branch.province || "",
    postalCode: branch.postalCode || "",
    phone: branch.phone || "",
    email: branch.email || "",
    location: {
      lat: Number.isFinite(Number(branch.location?.lat)) ? Number(branch.location.lat) : null,
      lng: Number.isFinite(Number(branch.location?.lng)) ? Number(branch.location.lng) : null
    }
  };
}

async function resolveRecommendedDeliveryCenterForSeller(seller) {
  const lat = Number(seller?.addressLocation?.lat);
  const lng = Number(seller?.addressLocation?.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return null;
  }

  const closestBranch = await findClosestBranch({ lat, lng });
  return serializeDeliveryCenter(closestBranch);
}


/**
 * ======================================================
 * CREATE ORDER (CHECKOUT)
 * POST /api/orders
 * ======================================================
 */
export async function createOrder(req, res) {
  try {
    const { shippingAddress } = req.body;

    // 1️⃣ Get user's cart
    const cart = await Cart.findOne({ userId: req.user.id });

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({
        message: "Cart is empty"
      });
    }

    /**
     * 2️⃣ Group cart items by sellerId
     */
    const groupedBySeller = {};

    cart.items.forEach((item) => {
      const sellerId = item.sellerId.toString();

      if (!groupedBySeller[sellerId]) {
        groupedBySeller[sellerId] = [];
      }

      groupedBySeller[sellerId].push(item);
    });

    /**
     * 3️⃣ Create one order PER seller
     */
    const createdOrders = [];

    for (const sellerId in groupedBySeller) {
      const items = groupedBySeller[sellerId];

      const totalAmount = items.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      );

      /**
       * Calculate Delivery Charge for this seller
       */
      const seller = await Seller.findById(sellerId);
      const sellerLocation = seller?.addressLocation || null;
      const customerLocation = shippingAddress ? { 
        lat: shippingAddress.lat, 
        lng: shippingAddress.lng 
      } : null;

      const deliveryCharge = await getOrderDeliveryCharge(sellerLocation, customerLocation);

      // 🛒 Get Active Commission Policy
      const activePolicy = await CommissionPolicy.findOne({ isActive: true }).sort({ effectiveFrom: -1 });
      const commissionRate = activePolicy ? activePolicy.rate : 0;
      
      // Calculate commission ONLY on productTotal (which is totalAmount here before adding deliveryCharge)
      const commissionAmount = Math.round((totalAmount * commissionRate) / 100);
      const sellerPayableAmount = totalAmount - commissionAmount;

      const order = await Order.create({
        userId: req.user.id,
        sellerId,
        items: items.map((item) => ({
          productId: item.productId,
          sellerOfferId: item.sellerOfferId,
          price: item.price,
          quantity: item.quantity
        })),
        productTotal: totalAmount,
        deliveryCharge,
        totalAmount: totalAmount + deliveryCharge,
        commissionRate,
        commissionAmount,
        sellerPayableAmount,
        commissionPolicyId: activePolicy ? activePolicy._id : null,
        ...(shippingAddress && { shippingAddress })
      });

      createdOrders.push(order);
    }

    /**
     * 4️⃣ Clear cart after successful checkout
     */
    cart.items = [];
    await cart.save();


    res.status(201).json({
      message: "Order placed successfully",
      orders: createdOrders,
    });

  } catch (error) {
    console.error("❌ Create order error:", error);
    res.status(500).json({
      message: "Failed to place order",
      error: error.message
    });
  }
}


/**
 * ======================================================
 * GET BUYER ORDERS
 * GET /api/orders/my
 * ======================================================
 */
export async function getMyOrders(req, res) {
  try {
    const orders = await Order.find({ userId: req.user.id })
      .populate("sellerId", "shopName")
      .sort({ createdAt: -1 });

    res.json(orders);

  } catch (error) {
    console.error("❌ Get buyer orders error:", error);
    res.status(500).json({
      message: "Failed to fetch orders",
      error: error.message
    });
  }
}


/**
 * ======================================================
 * GET AUTHENTICATED SELLER ORDERS
 * GET /api/orders/seller/me
 * ======================================================
 */
export async function getMySellerOrders(req, res) {
  try {
    const seller = await getSellerFromAuthUser(req.user);

    if (!seller) {
      return res.status(403).json({ message: "Access denied. Seller account required." });
    }

    const recommendedDeliveryCenter = await resolveRecommendedDeliveryCenterForSeller(seller);

    const orders = await Order.find({ sellerId: seller._id })
      .populate("userId", "email firstName lastName phone")
      .populate("sellerId", "shopName email")
      .populate("items.productId", "productName")
      .sort({ createdAt: -1 });

    const ordersWithCenter = orders.map((order) => ({
      ...order.toObject(),
      recommendedDeliveryCenter
    }));

    res.json(ordersWithCenter);
  } catch (error) {
    console.error("❌ Get authenticated seller orders error:", error);
    res.status(500).json({
      message: "Failed to fetch seller orders",
      error: error.message
    });
  }
}

/**
 * ======================================================
 * GET AUTHENTICATED SELLER ORDER BY ID
 * GET /api/orders/seller/me/:orderId
 * ======================================================
 */
export async function getMySellerOrderById(req, res) {
  try {
    const seller = await getSellerFromAuthUser(req.user);

    if (!seller) {
      return res.status(403).json({ message: "Access denied. Seller account required." });
    }

    const order = await Order.findOne({ _id: req.params.orderId, sellerId: seller._id })
      .populate("userId", "email firstName lastName phone")
      .populate("sellerId", "shopName email")
      .populate("items.productId", "productName");

    if (!order) {
      return res.status(404).json({ message: "Order not found for this seller." });
    }

    const recommendedDeliveryCenter = await resolveRecommendedDeliveryCenterForSeller(seller);

    res.json({
      ...order.toObject(),
      recommendedDeliveryCenter
    });
  } catch (error) {
    console.error("❌ Get authenticated seller order by ID error:", error);
    res.status(500).json({
      message: "Failed to fetch seller order details",
      error: error.message
    });
  }
}


/**
 * ======================================================
 * SELLER SUBMITS PACKING PROOF
 * POST /api/orders/seller/me/:orderId/packing-proof
 * Body (multipart/form-data): productName, skuOrImei, proofImage
 * ======================================================
 */
export async function submitSellerPackingProof(req, res) {
  try {
    const seller = await getSellerFromAuthUser(req.user);
    if (!seller) {
      return res.status(403).json({ message: "Access denied. Seller account required." });
    }

    const { orderId } = req.params;
    const { productName, skuOrImei } = req.body;

    if (!productName?.trim()) {
      return res.status(400).json({ message: "Packed product name is required." });
    }
    if (!skuOrImei?.trim()) {
      return res.status(400).json({ message: "SKU/IMEI is required." });
    }
    if (!req.file) {
      return res.status(400).json({ message: "Packing proof image is required." });
    }
    if (!req.file.mimetype?.startsWith("image/")) {
      return res.status(400).json({ message: "Packing proof must be an image file." });
    }

    const order = await Order.findOne({ _id: orderId, sellerId: seller._id })
      .populate("userId", "email firstName lastName phone")
      .populate("sellerId", "shopName email")
      .populate("items.productId", "productName");

    if (!order) {
      return res.status(404).json({ message: "Order not found for this seller." });
    }

    if (order.status === "cancelled") {
      return res.status(400).json({ message: "Cannot submit proof for a cancelled order." });
    }

    const proofImageUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
    order.sellerQr = {
      ...order.sellerQr,
      verificationStatus: "pending",
      proofImageUrl,
      packingProductName: productName.trim(),
      packingSkuOrImei: skuOrImei.trim(),
      proofSubmittedAt: new Date(),
      proofSubmittedBy: req.user.id,
      verificationNote: "",
      verifiedBy: null,
      verifiedAt: null,
      qrPayload: null,
      qrGeneratedAt: null
    };

    await order.save();

    res.json({
      message: "Packing proof submitted successfully. Waiting for admin verification.",
      order
    });
  } catch (error) {
    console.error("❌ Submit seller packing proof error:", error);
    res.status(500).json({
      message: "Failed to submit packing proof",
      error: error.message
    });
  }
}


/**
 * ======================================================
 * GET SELLER QR FOR AN ORDER
 * GET /api/orders/seller/me/:orderId/seller-qr
 * ======================================================
 */
export async function getSellerOrderQr(req, res) {
  try {
    const seller = await getSellerFromAuthUser(req.user);
    if (!seller) {
      return res.status(403).json({ message: "Access denied. Seller account required." });
    }

    const order = await Order.findOne({ _id: req.params.orderId, sellerId: seller._id })
      .populate("userId", "email firstName lastName phone")
      .populate("sellerId", "shopName email")
      .populate("items.productId", "productName");

    if (!order) {
      return res.status(404).json({ message: "Order not found for this seller." });
    }

    if (order.sellerQr?.verificationStatus !== "approved") {
      return res.status(403).json({
        message: "Seller QR is available only after admin approval.",
        verificationStatus: order.sellerQr?.verificationStatus || "not_submitted"
      });
    }

    let qrPayload = order.sellerQr?.qrPayload;
    if (!isLatestSellerQrPayload(qrPayload)) {
      qrPayload = buildSellerQrPayload(order);
      order.sellerQr = {
        ...order.sellerQr,
        qrPayload,
        qrGeneratedAt: new Date()
      };
      await order.save();
    }

    const qrText = qrPayload.qrText || buildSellerQrText(qrPayload);
    const qrImageDataUrl = await QRCode.toDataURL(qrText, {
      errorCorrectionLevel: "L",
      version: 3,
      margin: 2,
      scale: 10,
      color: {
        dark: "#000000",
        light: "#FFFFFF"
      }
    });

    res.json({
      message: "Seller QR generated successfully.",
      verificationStatus: order.sellerQr.verificationStatus,
      qrGeneratedAt: order.sellerQr.qrGeneratedAt,
      qrPayload,
      qrText,
      qrImageDataUrl
    });
  } catch (error) {
    console.error("❌ Get seller QR error:", error);
    res.status(500).json({
      message: "Failed to generate seller QR",
      error: error.message
    });
  }
}


/**
 * ======================================================
 * GET SELLER ORDERS
 * GET /api/orders/seller/:sellerId
 * ======================================================
 */
export async function getSellerOrders(req, res) {
  try {
    const { sellerId } = req.params;

    const orders = await Order.find({ sellerId })
      .populate("userId", "email")
      .sort({ createdAt: -1 });

    res.json(orders);

  } catch (error) {
    console.error("❌ Get seller orders error:", error);
    res.status(500).json({
      message: "Failed to fetch seller orders",
      error: error.message
    });
  }
}

/**
 * ======================================================
 * GET DELIVERY CHARGE PREVIEW
 * POST /api/orders/preview-delivery
 * ======================================================
 */
export async function getDeliveryChargePreview(req, res) {
  try {
    const { shippingAddress } = req.body;
    
    // 1️⃣ Get user's cart
    const cart = await Cart.findOne({ userId: req.user.id });
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: "Cart is empty" });
    }

    // 2️⃣ Group items by seller to calculate fee per seller
    const sellerIds = [...new Set(cart.items.map(item => item.sellerId.toString()))];
    
    const previews = [];
    let totalDeliveryCharge = 0;

    for (const sellerId of sellerIds) {
      const seller = await Seller.findById(sellerId);
      const sellerLocation = seller?.addressLocation || null;
      const customerLocation = shippingAddress ? { 
        lat: shippingAddress.lat, 
        lng: shippingAddress.lng 
      } : null;

      const fee = await getOrderDeliveryCharge(sellerLocation, customerLocation);
      
      previews.push({
        sellerId,
        shopName: seller?.shopName || "Unknown Seller",
        deliveryCharge: fee
      });
      totalDeliveryCharge += fee;
    }

    res.json({
      previews,
      totalDeliveryCharge
    });

  } catch (error) {
    console.error("❌ Preview delivery charge error:", error);
    res.status(500).json({
      message: "Failed to calculate delivery charge",
      error: error.message
    });
  }
}



